package fi.dy.masa.malilib.gui.widgets;

import javax.annotation.Nullable;
import net.minecraft.client.gui.DrawContext;
import fi.dy.masa.malilib.gui.button.ButtonBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.GuiHotkeyWheelKeyComboDetails;
import fi.dy.masa.malilib.util.GuiUtils;
import fi.dy.masa.malilib.render.RenderUtils;

public class WidgetHotkeyWheelWhitelistEntry extends WidgetListEntryBase<WidgetListHotkeyWheelWhitelist.KeyComboRef>
{
    private final boolean isOdd;
    private final WidgetListHotkeyWheelWhitelist parent;
    private final ButtonGeneric checkButton;
    private final ButtonGeneric detailsButton;
    private final int checkButtonWidth;

    public WidgetHotkeyWheelWhitelistEntry(int x, int y, int width, int height,
            @Nullable WidgetListHotkeyWheelWhitelist.KeyComboRef entry, int listIndex, boolean isOdd,
            WidgetListHotkeyWheelWhitelist parent)
    {
        super(x, y, width, height, entry, listIndex);
        this.isOdd = isOdd;
        this.parent = parent;

        int bx = x + 2;
        int by = y + 2;
        int bw = 26;
        int bh = height - 4;
        this.checkButtonWidth = bw;

        this.checkButton = new ButtonGeneric(bx, by, bw, bh, this.getCheckLabel());
        this.addButton(this.checkButton, new ListenerToggle(this));

        int dbw = 46;
        this.detailsButton = new ButtonGeneric(x + width - dbw - 2, by, dbw, bh, "列表");
        this.addButton(this.detailsButton, new ListenerDetails(this));
    }

    private String getCheckLabel()
    {
        if (this.entry != null && this.parent.isSelected(this.entry))
        {
            return "§a✔§r";
        }
        return " ";
    }

    @Override
    public void render(int mouseX, int mouseY, boolean selected, DrawContext drawContext)
    {
        RenderUtils.color(1f, 1f, 1f, 1f);

        boolean checked = this.entry != null && this.parent.isSelected(this.entry);

        if (this.isOdd)
        {
            RenderUtils.drawRect(this.x, this.y, this.width, this.height, checked ? 0x5050A0FF : 0x20FFFFFF);
        }
        else
        {
            RenderUtils.drawRect(this.x, this.y, this.width, this.height, checked ? 0x6040A0FF : 0x30FFFFFF);
        }

        // Labels
        if (this.entry != null)
        {
            int tx = this.x + 2 + this.checkButtonWidth + 6;
            int ty = this.y + 5;
            this.drawStringWithShadow(tx, ty, 0xFFFFFFFF, this.entry.display, drawContext);

            String right = "绑定: " + this.entry.boundCount;
            int rw = this.getStringWidth(right);
            int rightX = this.detailsButton.getX() - rw - 6;
            this.drawStringWithShadow(rightX, ty, 0xA0A0A0A0, right, drawContext);
        }

        this.drawSubWidgets(mouseX, mouseY, drawContext);
        super.render(mouseX, mouseY, selected, drawContext);
    }

    private void toggle()
    {
        if (this.entry == null) return;
        this.parent.toggle(this.entry);
        this.checkButton.setDisplayString(this.getCheckLabel());
    }

    @Override
    protected boolean onMouseClickedImpl(int mouseX, int mouseY, int mouseButton)
    {
        if (mouseButton == 0 && this.entry != null)
        {
            // Click anywhere on the row toggles selection (more user friendly)
            this.toggle();
            return true;
        }

        return super.onMouseClickedImpl(mouseX, mouseY, mouseButton);
    }

    private static class ListenerToggle implements IButtonActionListener
    {
        private final WidgetHotkeyWheelWhitelistEntry parent;

        private ListenerToggle(WidgetHotkeyWheelWhitelistEntry parent)
        {
            this.parent = parent;
        }

        @Override
        public void actionPerformedWithButton(ButtonBase button, int mouseButton)
        {
            this.parent.toggle();
        }
    }

    private static class ListenerDetails implements IButtonActionListener
    {
        private final WidgetHotkeyWheelWhitelistEntry parent;

        private ListenerDetails(WidgetHotkeyWheelWhitelistEntry parent)
        {
            this.parent = parent;
        }

        @Override
        public void actionPerformedWithButton(ButtonBase button, int mouseButton)
        {
            if (this.parent.entry == null)
            {
                return;
            }

            GuiBase.openGui(new GuiHotkeyWheelKeyComboDetails(this.parent.entry.comboId, null, GuiUtils.getCurrentScreen()));
        }
    }
}

