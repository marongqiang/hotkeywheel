package fi.dy.masa.malilib.hotkeys.wheel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import org.lwjgl.glfw.GLFW;

import fi.dy.masa.malilib.hotkeys.IKeybind;
import fi.dy.masa.malilib.hotkeys.KeybindMulti;

public class HotkeyWheelKeyComboUtil
{
    private HotkeyWheelKeyComboUtil() {}

    public static String buildComboIdFromEvent(int keyCode, int modifiers)
    {
        String main = KeybindMulti.getStorageStringForKeyCode(keyCode);
        if (main == null || main.isEmpty())
        {
            return "";
        }

        List<String> parts = new ArrayList<>(5);

        // Order is stable for comparisons and UI readability
        if ((modifiers & GLFW.GLFW_MOD_CONTROL) != 0) parts.add("CTRL");
        if ((modifiers & GLFW.GLFW_MOD_SHIFT) != 0) parts.add("SHIFT");
        if ((modifiers & GLFW.GLFW_MOD_ALT) != 0) parts.add("ALT");
        if ((modifiers & GLFW.GLFW_MOD_SUPER) != 0) parts.add("SUPER");

        parts.add(main.toUpperCase(Locale.ROOT));
        return String.join(",", parts);
    }

    public static List<String> getComboIdsForKeybind(IKeybind keybind)
    {
        if (keybind == null)
        {
            return Collections.emptyList();
        }

        return getComboIdsForStorageString(keybind.getStringValue());
    }

    public static List<String> getComboIdsForStorageString(String storage)
    {
        if (storage == null)
        {
            return Collections.emptyList();
        }

        String[] parts = storage.split(",");
        if (parts.length == 0)
        {
            return Collections.emptyList();
        }

        boolean ctrl = false;
        boolean shift = false;
        boolean alt = false;
        boolean superKey = false;
        List<String> mains = new ArrayList<>(2);

        for (String raw : parts)
        {
            if (raw == null) continue;
            String k = raw.trim().toUpperCase(Locale.ROOT);
            if (k.isEmpty()) continue;

            // Normalize left/right modifiers to a single token
            if (k.equals("LEFT_CONTROL") || k.equals("RIGHT_CONTROL") || k.equals("CTRL"))
            {
                ctrl = true;
            }
            else if (k.equals("LEFT_SHIFT") || k.equals("RIGHT_SHIFT") || k.equals("SHIFT"))
            {
                shift = true;
            }
            else if (k.equals("LEFT_ALT") || k.equals("RIGHT_ALT") || k.equals("ALT"))
            {
                alt = true;
            }
            else if (k.equals("LEFT_SUPER") || k.equals("RIGHT_SUPER") || k.equals("SUPER"))
            {
                superKey = true;
            }
            else
            {
                mains.add(k);
            }
        }

        if (mains.isEmpty())
        {
            return Collections.emptyList();
        }

        List<String> out = new ArrayList<>(mains.size());
        for (String main : mains)
        {
            List<String> combo = new ArrayList<>(5);
            if (ctrl) combo.add("CTRL");
            if (shift) combo.add("SHIFT");
            if (alt) combo.add("ALT");
            if (superKey) combo.add("SUPER");
            combo.add(main);
            out.add(String.join(",", combo));
        }

        return out;
    }

    public static String comboIdToDisplayString(String comboId)
    {
        if (comboId == null)
        {
            return "";
        }

        String[] parts = comboId.split(",");
        if (parts.length == 0)
        {
            return "";
        }

        StringBuilder sb = new StringBuilder(32);
        for (int i = 0; i < parts.length; i++)
        {
            String p = parts[i].trim();
            if (p.isEmpty()) continue;
            if (sb.length() > 0) sb.append(" + ");

            // Friendly modifier names
            if (p.equalsIgnoreCase("CTRL")) sb.append("Ctrl");
            else if (p.equalsIgnoreCase("SHIFT")) sb.append("Shift");
            else if (p.equalsIgnoreCase("ALT")) sb.append("Alt");
            else if (p.equalsIgnoreCase("SUPER")) sb.append("Win");
            else sb.append(p);
        }
        return sb.toString();
    }
}

