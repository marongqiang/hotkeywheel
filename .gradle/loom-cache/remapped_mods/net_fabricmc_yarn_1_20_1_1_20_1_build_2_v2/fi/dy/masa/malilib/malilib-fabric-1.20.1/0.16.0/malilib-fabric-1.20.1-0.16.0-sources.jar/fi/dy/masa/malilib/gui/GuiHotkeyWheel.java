package fi.dy.masa.malilib.gui;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.Window;
import net.minecraft.screen.ScreenTexts;
import java.lang.reflect.Method;
import java.nio.DoubleBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.joml.Matrix4f;

import fi.dy.masa.malilib.MaLiLib;
import fi.dy.masa.malilib.hotkeys.IHotkey;
import fi.dy.masa.malilib.render.RenderUtils;
import fi.dy.masa.malilib.util.GuiUtils;

/**
 * A temporary overlay screen that captures the mouse to provide a true radial selection UI.
 * While this screen is open, the player's camera won't rotate.
 */
public class GuiHotkeyWheel extends Screen
{
    private final Screen parent;
    private final int activeKeyCode;
    private final List<IHotkey> entries;
    private int selectedIndex = -1;
    private int innerDeadzoneRadius = 18;
    private boolean pendingCursorCenter;
    private boolean cursorCenterConfirmed;
    private boolean loggedOpenMousePos;
    private int suppressSelectionFrames;
    private int debugMouseFrames;
    private boolean centerOnFocus;
    private boolean wasFocused;

    public GuiHotkeyWheel(Screen parent, int activeKeyCode, List<IHotkey> entries)
    {
        super(ScreenTexts.EMPTY);
        this.parent = parent;
        this.activeKeyCode = activeKeyCode;
        this.entries = entries;
    }

    public int getSelectedIndex()
    {
        return this.selectedIndex;
    }

    public int getActiveKeyCode()
    {
        return this.activeKeyCode;
    }

    @Override
    public boolean shouldPause()
    {
        return false;
    }

    @Override
    protected void init()
    {
        // Ensure cursor is visible and not locked to camera rotation
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.mouse.unlockCursor();
        this.selectedIndex = -1;
        this.cursorCenterConfirmed = false;
        this.loggedOpenMousePos = false;
        this.suppressSelectionFrames = 5;
        this.debugMouseFrames = 20;
        this.centerOnFocus = true;
        this.wasFocused = mc.isWindowFocused();

        // Center the cursor every time the wheel opens
        this.pendingCursorCenter = true;
        centerCursorNow(mc, GuiUtils.getScaledWindowWidth() / 2, GuiUtils.getScaledWindowHeight() / 2);
    }

    @Override
    public void removed()
    {
        // Return cursor control to vanilla in-game mode
        MinecraftClient.getInstance().mouse.lockCursor();
    }

    @Override
    public void render(DrawContext drawContext, int mouseX, int mouseY, float delta)
    {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = GuiUtils.getScaledWindowWidth();
        int sh = GuiUtils.getScaledWindowHeight();
        int cx = sw / 2;
        int cy = sh / 2;

        boolean focused = mc.isWindowFocused();
        if (focused == false)
        {
            // User may move the OS cursor while MC is in background.
            // When focus returns, re-center once to avoid "appearing" from the desktop position.
            this.centerOnFocus = true;
            this.wasFocused = false;
        }
        else if (this.wasFocused == false)
        {
            // Focus regained
            this.wasFocused = true;
            if (this.centerOnFocus)
            {
                this.centerOnFocus = false;
                this.pendingCursorCenter = false;
                this.cursorCenterConfirmed = false;
                this.suppressSelectionFrames = 5;
                this.selectedIndex = -1;
                centerCursorNow(mc, cx, cy);
            }
        }

        if (this.debugMouseFrames > 0)
        {
            this.debugMouseFrames--;
            Window w = mc.getWindow();

            double glfwX = Double.NaN;
            double glfwY = Double.NaN;
            try (MemoryStack stack = MemoryStack.stackPush())
            {
                long handle = w.getHandle();
                if (handle != MemoryUtil.NULL)
                {
                    var px = stack.mallocDouble(1);
                    var py = stack.mallocDouble(1);
                    GLFW.glfwGetCursorPos(handle, px, py);
                    glfwX = px.get(0);
                    glfwY = py.get(0);
                }
            }

            MaLiLib.logger.info(
                    "HotkeyWheel frame: scaledMouse=({},{}), scaledCenter=({},{}), confirmed={}, suppressFrames={}, scaleFactor={}, glfwCursor=({},{})",
                    mouseX, mouseY, cx, cy,
                    this.cursorCenterConfirmed,
                    this.suppressSelectionFrames,
                    w.getScaleFactor(),
                    glfwX, glfwY
            );
        }

        if (this.loggedOpenMousePos == false)
        {
            this.loggedOpenMousePos = true;
            Window w = mc.getWindow();

            double glfwX = Double.NaN;
            double glfwY = Double.NaN;
            try (MemoryStack stack = MemoryStack.stackPush())
            {
                long handle = w.getHandle();
                if (handle != MemoryUtil.NULL)
                {
                    var px = stack.mallocDouble(1);
                    var py = stack.mallocDouble(1);
                    GLFW.glfwGetCursorPos(handle, px, py);
                    glfwX = px.get(0);
                    glfwY = py.get(0);
                }
            }

            MaLiLib.logger.info(
                    "HotkeyWheel open: scaledMouse=({},{}), scaledCenter=({},{}), winSize=({},{}), scaleFactor={}, glfwCursor=({},{})",
                    mouseX, mouseY, cx, cy,
                    w.getWidth(), w.getHeight(),
                    w.getScaleFactor(),
                    glfwX, glfwY
            );
        }

        if (this.pendingCursorCenter || this.cursorCenterConfirmed == false)
        {
            this.pendingCursorCenter = false;
            centerCursorNow(mc, cx, cy);

            if (Math.abs(mouseX - cx) <= 1 && Math.abs(mouseY - cy) <= 1)
            {
                this.cursorCenterConfirmed = true;
            }
            else
            {
                this.selectedIndex = -1;
            }
        }

        // Ensure alpha fills & sector highlight are visible on top of the world
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableCull();

        if (this.cursorCenterConfirmed)
        {
            if (this.suppressSelectionFrames > 0)
            {
                // Prevent inheriting a "previous direction" during the first frames after opening
                // (mouse deltas/cached state can settle a frame later on some setups).
                this.suppressSelectionFrames--;
                this.selectedIndex = -1;
            }
            else
            {
                this.updateSelection(mouseX, mouseY);
            }
        }

        if (this.entries == null || this.entries.isEmpty())
        {
            return;
        }

        // Diameter ≈ 2/3 of the screen height (and fit width too)
        int radius = Math.min((int) (sh * 0.333f), (int) (sw * 0.333f));
        radius = Math.min(radius, (Math.min(sw, sh) / 2) - 20);
        radius = Math.max(radius, 90);
        this.innerDeadzoneRadius = Math.max(22, (int) (radius * 0.28f));

        // Full-screen dim background
        drawContext.fill(0, 0, sw, sh, 0x7A000000);

        Matrix4f mat = drawContext.getMatrices().peek().getPositionMatrix();

        // Circular background (no blur; just translucent disk)
        drawFilledCircle(mat, cx, cy, radius, 0x88101010);

        int n = this.entries.size();
        for (int i = 0; i < n; i++)
        {
            double start = (-Math.PI / 2.0) + (2.0 * Math.PI) * ((double) i / (double) n);
            double end = (-Math.PI / 2.0) + (2.0 * Math.PI) * ((double) (i + 1) / (double) n);

            // Selection: make both sector and label yellow
            int fill = (i == this.selectedIndex) ? 0xF0FFD800 : 0x60202020;
            drawFilledSector(mat, cx, cy, radius, start, end, fill);

            // Sector separators
            int sep = 0xA0FFFFFF;
            drawRadialLine(mat, cx, cy, radius, start, sep);
            if (i == n - 1)
            {
                drawRadialLine(mat, cx, cy, radius, end, sep);
            }

            // Label at mid-angle, near the edge (like the reference image)
            double mid = (start + end) * 0.5;
            int tx = cx + (int) (Math.cos(mid) * (radius + 26));
            int ty = cy + (int) (Math.sin(mid) * (radius + 26));
            String label = this.entries.get(i).getConfigGuiDisplayName();
            int textW = mc.textRenderer.getWidth(label);
            int textColor = (i == this.selectedIndex) ? 0xFFFFD800 : 0xE8E8E8;
            drawContext.drawTextWithShadow(mc.textRenderer, label, tx - textW / 2, ty - 4, textColor);
        }

        // Outer ring
        drawCircleOutline(mat, cx, cy, radius, 0xC0FFFFFF);

        // Inner ring (deadzone = do nothing)
        drawFilledCircle(mat, cx, cy, this.innerDeadzoneRadius, 0xB0101010);
        drawCircleOutline(mat, cx, cy, this.innerDeadzoneRadius, 0xC0FFFFFF);

        // Center dot
        RenderUtils.drawRect(cx - 2, cy - 2, 4, 4, 0xB0FFFFFF);

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
    }

    private void updateSelection(int mouseX, int mouseY)
    {
        int sw = GuiUtils.getScaledWindowWidth();
        int sh = GuiUtils.getScaledWindowHeight();
        int cx = sw / 2;
        int cy = sh / 2;

        double dx = mouseX - cx;
        double dy = mouseY - cy;
        double dist2 = dx * dx + dy * dy;

        int n = this.entries.size();
        int inner = this.innerDeadzoneRadius;
        if (n <= 0 || dist2 < (double) inner * (double) inner)
        {
            this.selectedIndex = -1;
            return;
        }

        double ang = Math.atan2(dy, dx);
        double norm = ang + Math.PI / 2.0; // 0 = up
        if (norm < 0)
        {
            norm += 2.0 * Math.PI;
        }

        int idx = (int) Math.floor((norm / (2.0 * Math.PI)) * n);
        if (idx < 0) idx = 0;
        if (idx >= n) idx = n - 1;
        this.selectedIndex = idx;
    }

    private static void drawFilledCircle(Matrix4f mat, int cx, int cy, int radius, int color)
    {
        drawFilledSector(mat, cx, cy, radius, 0.0, Math.PI * 2.0, color);
    }

    private static void drawFilledSector(Matrix4f mat, int cx, int cy, int radius, double startAngle, double endAngle, int color)
    {
        float a = (float) (color >> 24 & 255) / 255.0F;
        float r = (float) (color >> 16 & 255) / 255.0F;
        float g = (float) (color >> 8 & 255) / 255.0F;
        float b = (float) (color & 255) / 255.0F;

        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();

        // Triangulate the arc
        int steps = Math.max(6, (int) Math.ceil(Math.abs(endAngle - startAngle) / (Math.PI / 18.0)));
        buf.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        float z = 0.0f;
        buf.vertex(mat, (float) cx, (float) cy, z).color(r, g, b, a).next();

        for (int i = 0; i <= steps; i++)
        {
            double t = startAngle + (endAngle - startAngle) * ((double) i / (double) steps);
            float vx = (float) (cx + Math.cos(t) * radius);
            float vy = (float) (cy + Math.sin(t) * radius);
            buf.vertex(mat, vx, vy, z).color(r, g, b, a).next();
        }

        tess.draw();
    }

    private static void drawRadialLine(Matrix4f mat, int cx, int cy, int radius, double angle, int color)
    {
        float a = (float) (color >> 24 & 255) / 255.0F;
        float r = (float) (color >> 16 & 255) / 255.0F;
        float g = (float) (color >> 8 & 255) / 255.0F;
        float b = (float) (color & 255) / 255.0F;

        float x2 = (float) (cx + Math.cos(angle) * radius);
        float y2 = (float) (cy + Math.sin(angle) * radius);

        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();

        buf.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        float z = 0.0f;
        buf.vertex(mat, (float) cx, (float) cy, z).color(r, g, b, a).next();
        buf.vertex(mat, x2, y2, z).color(r, g, b, a).next();
        tess.draw();
    }

    private static void drawCircleOutline(Matrix4f mat, int cx, int cy, int radius, int color)
    {
        float a = (float) (color >> 24 & 255) / 255.0F;
        float r = (float) (color >> 16 & 255) / 255.0F;
        float g = (float) (color >> 8 & 255) / 255.0F;
        float b = (float) (color & 255) / 255.0F;

        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();

        int steps = 80;
        buf.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        float z = 0.0f;
        for (int i = 0; i <= steps; i++)
        {
            double t = (Math.PI * 2.0) * ((double) i / (double) steps);
            float vx = (float) (cx + Math.cos(t) * radius);
            float vy = (float) (cy + Math.sin(t) * radius);
            buf.vertex(mat, vx, vy, z).color(r, g, b, a).next();
        }
        tess.draw();
    }

    private static void centerCursorNow(MinecraftClient mc, int scaledCenterX, int scaledCenterY)
    {
        Window w = mc.getWindow();
        double scale = w.getScaleFactor();
        double x = scaledCenterX * scale;
        double y = scaledCenterY * scale;
        GLFW.glfwSetCursorPos(w.getHandle(), x, y);
        // Also update MC's internal mouse position (method is private; name can vary)
        try
        {
            Method m = null;
            try
            {
                m = mc.mouse.getClass().getDeclaredMethod("onCursorPos", long.class, double.class, double.class);
            }
            catch (Exception ignored)
            {
            }

            if (m == null)
            {
                for (Method cand : mc.mouse.getClass().getDeclaredMethods())
                {
                    Class<?>[] p = cand.getParameterTypes();
                    if (p.length == 3 && p[0] == long.class && p[1] == double.class && p[2] == double.class)
                    {
                        m = cand;
                        break;
                    }
                }
            }

            if (m != null)
            {
                m.setAccessible(true);
                m.invoke(mc.mouse, w.getHandle(), x, y);
            }
        }
        catch (Exception ignored)
        {
        }
    }
}

