package fi.dy.masa.malilib.gui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import fi.dy.masa.malilib.MaLiLibConfigs;
import fi.dy.masa.malilib.config.ConfigManager;
import fi.dy.masa.malilib.event.InputEventHandler;
import fi.dy.masa.malilib.gui.button.ButtonBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import fi.dy.masa.malilib.gui.interfaces.IDialogHandler;
import fi.dy.masa.malilib.hotkeys.wheel.HotkeyWheelKeyComboUtil;
import fi.dy.masa.malilib.render.RenderUtils;
import fi.dy.masa.malilib.util.GuiUtils;
import fi.dy.masa.malilib.util.StringUtils;
import fi.dy.masa.malilib.gui.widgets.WidgetListHotkeyWheelKeyComboDetails;

public class GuiHotkeyWheelKeyComboDetails extends GuiListBase<WidgetListHotkeyWheelKeyComboDetails.HotkeyRef,
        fi.dy.masa.malilib.gui.widgets.WidgetHotkeyWheelKeyComboDetailsEntry,
        WidgetListHotkeyWheelKeyComboDetails>
{
    protected final String comboId;
    protected final String comboDisplay;
    @Nullable protected final IDialogHandler dialogHandler;

    protected int dialogWidth;
    protected int dialogHeight;
    protected int dialogLeft;
    protected int dialogTop;

    public GuiHotkeyWheelKeyComboDetails(String comboId, @Nullable IDialogHandler dialogHandler, Screen parent)
    {
        super(0, 0);
        this.comboId = comboId;
        this.comboDisplay = HotkeyWheelKeyComboUtil.comboIdToDisplayString(comboId);
        this.dialogHandler = dialogHandler;
        this.title = "轮盘条目 - " + this.comboDisplay;

        if (this.dialogHandler == null)
        {
            this.setParent(parent);
        }
    }

    @Override
    public void initGui()
    {
        int sw = GuiUtils.getScaledWindowWidth();
        int sh = GuiUtils.getScaledWindowHeight();
        this.dialogWidth = Math.min(560, Math.max(380, sw - 80));
        this.dialogHeight = Math.min(260 + (sh * 2 / 3), Math.max(220, sh - 80));
        this.centerOnScreen();
        this.reCreateListWidget();
        super.initGui();

        int bx = this.dialogLeft + this.dialogWidth - 10;
        int by = this.dialogTop + 4;
        bx -= this.addTopButton(bx, by, "完成", TopAction.DONE) + 4;
        bx -= this.addTopButton(bx, by, "全选", TopAction.ENABLE_ALL) + 4;
        bx -= this.addTopButton(bx, by, "全不选", TopAction.DISABLE_ALL) + 4;
    }

    private int addTopButton(int rightX, int y, String label, TopAction action)
    {
        ButtonGeneric btn = new ButtonGeneric(rightX, y, -1, true, label);
        this.addButton(btn, new ListenerTopButton(action, this));
        return btn.getWidth();
    }

    protected void centerOnScreen()
    {
        if (this.getParent() != null)
        {
            this.dialogLeft = this.getParent().width / 2 - this.dialogWidth / 2;
            this.dialogTop = this.getParent().height / 2 - this.dialogHeight / 2;
        }
        else
        {
            this.dialogLeft = 20;
            this.dialogTop = 20;
        }
        this.setListPosition(this.dialogLeft + 10, this.dialogTop + 20);
    }

    @Override
    protected int getBrowserWidth()
    {
        return this.dialogWidth - 14;
    }

    @Override
    protected int getBrowserHeight()
    {
        return this.dialogHeight - 30;
    }

    @Override
    protected WidgetListHotkeyWheelKeyComboDetails createListWidget(int listX, int listY)
    {
        return new WidgetListHotkeyWheelKeyComboDetails(listX, listY, this.getBrowserWidth(), this.getBrowserHeight(), this.comboId);
    }

    @Override
    public void removed()
    {
        // Persist disabled list
        List<String> out = new ArrayList<>(this.getListWidget().getDisabledIds());
        Collections.sort(out, String::compareToIgnoreCase);
        MaLiLibConfigs.Generic.HOTKEY_WHEEL_DISABLED_PER_COMBO.setStrings(out);
        ConfigManager.getInstance().onConfigsChanged("malilib");
        InputEventHandler.getKeybindManager().updateUsedKeys();
        super.removed();
    }

    @Override
    protected void drawScreenBackground(int mouseX, int mouseY)
    {
        RenderUtils.drawOutlinedBox(this.dialogLeft, this.dialogTop, this.dialogWidth, this.dialogHeight, 0xFF000000, COLOR_HORIZONTAL_BAR);
    }

    @Override
    protected void drawTitle(DrawContext drawContext, int mouseX, int mouseY, float partialTicks)
    {
        this.drawStringWithShadow(drawContext, this.title, this.dialogLeft + 10, this.dialogTop + 6, COLOR_WHITE);
        int total = this.getListWidget().getCurrentEntries().size();
        int disabled = this.getListWidget().getDisabledIds().size();
        String hint = "总数: " + total + "  |  不参与: " + disabled + "  |  点击任意一行可开关";
        this.drawStringWithShadow(drawContext, hint, this.dialogLeft + 10, this.dialogTop + 6 + 12, 0xA0A0A0A0);
    }

    private enum TopAction
    {
        DONE,
        ENABLE_ALL,
        DISABLE_ALL
    }

    private static class ListenerTopButton implements IButtonActionListener
    {
        private final TopAction action;
        private final GuiHotkeyWheelKeyComboDetails parent;

        private ListenerTopButton(TopAction action, GuiHotkeyWheelKeyComboDetails parent)
        {
            this.action = action;
            this.parent = parent;
        }

        @Override
        public void actionPerformedWithButton(ButtonBase button, int mouseButton)
        {
            if (this.action == TopAction.DONE)
            {
                this.parent.closeGui(true);
            }
            else if (this.action == TopAction.ENABLE_ALL)
            {
                this.parent.getListWidget().getDisabledIds().clear();
                this.parent.initGui();
            }
            else if (this.action == TopAction.DISABLE_ALL)
            {
                Set<String> all = this.parent.getListWidget().getAllIds();
                this.parent.getListWidget().getDisabledIds().clear();
                this.parent.getListWidget().getDisabledIds().addAll(all);
                this.parent.initGui();
            }
        }
    }
}

