package fi.dy.masa.malilib.gui.button;

import javax.annotation.Nullable;
import fi.dy.masa.malilib.config.IConfigStringList;
import fi.dy.masa.malilib.MaLiLibConfigs;
import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.GuiStringListEdit;
import fi.dy.masa.malilib.gui.GuiHotkeyWheelWhitelistEdit;
import fi.dy.masa.malilib.gui.interfaces.IConfigGui;
import fi.dy.masa.malilib.gui.interfaces.IDialogHandler;
import fi.dy.masa.malilib.util.GuiUtils;
import fi.dy.masa.malilib.util.StringUtils;

public class ConfigButtonStringList extends ButtonGeneric
{
    private final IConfigStringList config;
    private final IConfigGui configGui;
    @Nullable private final IDialogHandler dialogHandler;

    public ConfigButtonStringList(int x, int y, int width, int height, IConfigStringList config, IConfigGui configGui, @Nullable IDialogHandler dialogHandler)
    {
        super(x, y, width, height, "");

        this.config = config;
        this.configGui = configGui;
        this.dialogHandler = dialogHandler;

        this.updateDisplayString();
    }

    @Override
    protected boolean onMouseClickedImpl(int mouseX, int mouseY, int mouseButton)
    {
        super.onMouseClickedImpl(mouseX, mouseY, mouseButton);

        if (this.config == MaLiLibConfigs.Generic.HOTKEY_WHEEL_WHITELIST)
        {
            if (this.dialogHandler != null)
            {
                this.dialogHandler.openDialog(new GuiHotkeyWheelWhitelistEdit(this.config, this.configGui, this.dialogHandler, null));
            }
            else
            {
                GuiBase.openGui(new GuiHotkeyWheelWhitelistEdit(this.config, this.configGui, null, GuiUtils.getCurrentScreen()));
            }

            return true;
        }

        if (this.dialogHandler != null)
        {
            this.dialogHandler.openDialog(new GuiStringListEdit(this.config, this.configGui, this.dialogHandler, null));
        }
        else
        {
            GuiBase.openGui(new GuiStringListEdit(this.config, this.configGui, null, GuiUtils.getCurrentScreen()));
        }

        return true;
    }

    @Override
    public void updateDisplayString()
    {
        if (this.config == MaLiLibConfigs.Generic.HOTKEY_WHEEL_WHITELIST)
        {
            int count = this.config.getStrings() != null ? this.config.getStrings().size() : 0;
            this.displayString = count > 0 ? ("[ 已选: " + count + " ]") : "[ <empty> ]";
        }
        else
        {
            this.displayString = StringUtils.getClampedDisplayStringRenderlen(this.config.getStrings(), this.width - 10, "[ ", " ]");
        }
    }
}
