package fi.dy.masa.malilib.gui.widgets;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.annotation.Nullable;

import fi.dy.masa.malilib.MaLiLibConfigs;
import fi.dy.masa.malilib.MaLiLibReference;
import fi.dy.masa.malilib.event.InputEventHandler;
import fi.dy.masa.malilib.gui.LeftRight;
import fi.dy.masa.malilib.gui.MaLiLibIcons;
import fi.dy.masa.malilib.hotkeys.IHotkey;
import fi.dy.masa.malilib.hotkeys.IKeybind;
import fi.dy.masa.malilib.hotkeys.KeybindCategory;
import fi.dy.masa.malilib.hotkeys.wheel.HotkeyWheelKeyComboUtil;

public class WidgetListHotkeyWheelKeyComboDetails extends WidgetListBase<WidgetListHotkeyWheelKeyComboDetails.HotkeyRef,
        WidgetHotkeyWheelKeyComboDetailsEntry>
{
    public static class HotkeyRef
    {
        public final String modName;
        public final String hotkeyName;
        public final String displayName;

        public HotkeyRef(String modName, String hotkeyName, String displayName)
        {
            this.modName = modName;
            this.hotkeyName = hotkeyName;
            this.displayName = displayName;
        }

        public String getIdForCombo(String comboId)
        {
            return (comboId.toUpperCase(Locale.ROOT) + "|" + this.modName + "|" + this.hotkeyName);
        }
    }

    private final String comboId;
    private final Set<String> disabledIds = new HashSet<>();

    public WidgetListHotkeyWheelKeyComboDetails(int x, int y, int width, int height, String comboId)
    {
        super(x, y, width, height, null);
        this.comboId = comboId.toUpperCase(Locale.ROOT);
        this.widgetSearchBar = new WidgetSearchBar(x + 2, y + 4, width - 14, 14, 0, MaLiLibIcons.SEARCH, LeftRight.LEFT);
        this.browserEntriesOffsetY = 17;
        this.browserEntryHeight = 18;
        this.shouldSortList = false;

        for (String s : MaLiLibConfigs.Generic.HOTKEY_WHEEL_DISABLED_PER_COMBO.getStrings())
        {
            if (s != null && s.trim().isEmpty() == false)
            {
                this.disabledIds.add(s.trim());
            }
        }
    }

    public Set<String> getDisabledIds()
    {
        return this.disabledIds;
    }

    public Set<String> getAllIds()
    {
        Set<String> ids = new HashSet<>();
        for (HotkeyRef ref : this.getCurrentEntries())
        {
            if (ref != null)
            {
                ids.add(ref.getIdForCombo(this.comboId));
            }
        }
        return ids;
    }

    public boolean isDisabled(HotkeyRef ref)
    {
        if (ref == null) return false;
        return this.disabledIds.contains(ref.getIdForCombo(this.comboId));
    }

    public void toggle(HotkeyRef ref)
    {
        if (ref == null) return;
        String id = ref.getIdForCombo(this.comboId);
        if (this.disabledIds.contains(id))
        {
            this.disabledIds.remove(id);
        }
        else
        {
            this.disabledIds.add(id);
        }
    }

    @Override
    protected Collection<HotkeyRef> getAllEntries()
    {
        List<KeybindCategory> categories = InputEventHandler.getKeybindManager().getKeybindCategories();
        List<HotkeyRef> out = new ArrayList<>();

        for (KeybindCategory category : categories)
        {
            if (category == null) continue;
            if (MaLiLibReference.MOD_NAME.equals(category.getModName()))
            {
                continue;
            }

            for (IHotkey hk : category.getHotkeys())
            {
                if (hk == null) continue;
                IKeybind kb = hk.getKeybind();
                if (kb == null || kb.getKeys().isEmpty()) continue;

                boolean matches = false;
                for (String cid : HotkeyWheelKeyComboUtil.getComboIdsForKeybind(kb))
                {
                    if (cid.equalsIgnoreCase(this.comboId))
                    {
                        matches = true;
                        break;
                    }
                }

                if (matches)
                {
                    out.add(new HotkeyRef(category.getModName(), hk.getName(), hk.getConfigGuiDisplayName()));
                }
            }
        }

        out.sort((a, b) ->
        {
            int c = a.modName.compareToIgnoreCase(b.modName);
            if (c != 0) return c;
            c = a.displayName.compareToIgnoreCase(b.displayName);
            if (c != 0) return c;
            return a.hotkeyName.compareToIgnoreCase(b.hotkeyName);
        });

        return out;
    }

    @Override
    protected List<String> getEntryStringsForFilter(HotkeyRef entry)
    {
        if (entry == null) return Collections.emptyList();
        List<String> list = new ArrayList<>();
        list.add(entry.modName.toLowerCase(Locale.ROOT));
        list.add(entry.hotkeyName.toLowerCase(Locale.ROOT));
        list.add(entry.displayName.toLowerCase(Locale.ROOT));
        return list;
    }

    @Override
    protected WidgetHotkeyWheelKeyComboDetailsEntry createListEntryWidget(int x, int y, int listIndex, boolean isOdd, @Nullable HotkeyRef entry)
    {
        return new WidgetHotkeyWheelKeyComboDetailsEntry(x, y, this.browserEntryWidth, this.browserEntryHeight, entry, listIndex, isOdd, this);
    }
}

