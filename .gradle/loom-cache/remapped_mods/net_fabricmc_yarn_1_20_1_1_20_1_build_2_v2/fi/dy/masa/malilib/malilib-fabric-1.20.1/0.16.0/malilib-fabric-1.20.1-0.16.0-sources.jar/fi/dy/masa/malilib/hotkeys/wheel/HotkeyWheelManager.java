package fi.dy.masa.malilib.hotkeys.wheel;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;
import fi.dy.masa.malilib.MaLiLibConfigs;
import fi.dy.masa.malilib.gui.Message;
import fi.dy.masa.malilib.event.InputEventHandler;
import fi.dy.masa.malilib.MaLiLibReference;
import fi.dy.masa.malilib.config.IHotkeyTogglable;
import fi.dy.masa.malilib.gui.GuiHotkeyWheel;
import fi.dy.masa.malilib.hotkeys.IHotkey;
import fi.dy.masa.malilib.hotkeys.IHotkeyCallback;
import fi.dy.masa.malilib.hotkeys.IKeyboardInputHandler;
import fi.dy.masa.malilib.hotkeys.IMouseInputHandler;
import fi.dy.masa.malilib.hotkeys.IKeybind;
import fi.dy.masa.malilib.hotkeys.KeyAction;
import fi.dy.masa.malilib.hotkeys.KeybindCategory;
import fi.dy.masa.malilib.hotkeys.KeybindMulti;
import fi.dy.masa.malilib.interfaces.IClientTickHandler;
import fi.dy.masa.malilib.interfaces.IRenderer;
import fi.dy.masa.malilib.render.RenderUtils;
import fi.dy.masa.malilib.util.InfoUtils;
import fi.dy.masa.malilib.util.GuiUtils;

/**
 * GTA-style radial hotkey wheel, global for all malilib-based mods.
 *
 * Activation: hold the configured keybind; move mouse to select; release to trigger.
 *
 * Bindings: each slot stores a reference in the format:
 *   "<modName>|<categoryKey>|<hotkeyName>"
 * which is matched against registered malilib hotkeys.
 */
public class HotkeyWheelManager implements IRenderer, IKeyboardInputHandler, IMouseInputHandler, IClientTickHandler
{
    public static final HotkeyWheelManager INSTANCE = new HotkeyWheelManager();

    private final MinecraftClient mc = MinecraftClient.getInstance();

    private boolean open;
    private int selectedIndex = -1;
    private int activeKeyCode = -1;
    private final List<IHotkey> activeEntries = new ArrayList<>();
    private GuiHotkeyWheel screen;
    private Screen parentScreen;

    private HotkeyWheelManager() {}

    @Override
    public Supplier<String> getProfilerSectionSupplier()
    {
        return () -> "malilib_hotkey_wheel";
    }

    @Override
    public void onClientTick(MinecraftClient mc)
    {
        if (mc.player == null || mc.world == null)
        {
            this.open = false;
            return;
        }

        if (this.open && this.screen != null)
        {
            this.selectedIndex = this.screen.getSelectedIndex();
        }
    }

    @Override
    public boolean onKeyInput(int keyCode, int scanCode, int modifiers, boolean eventKeyState)
    {
        // Allow closing from inside the wheel screen; otherwise ignore while GUI open.
        if (this.mc.currentScreen != null && this.mc.currentScreen != this.screen)
        {
            return false;
        }

        // If wheel is open, we only care about the active key release; swallow everything.
        if (this.open)
        {
            if (eventKeyState == false && keyCode == this.activeKeyCode)
            {
                this.triggerSelected();
                this.close();
            }
            return true;
        }

        // Key press: build list of all malilib hotkeys bound to this single key.
        if (eventKeyState)
        {
            if (this.isWheelBlockedByWhitelistForKeyPress(keyCode, modifiers))
            {
                return false;
            }

            List<IHotkey> entries = this.collectHotkeysBoundToKeyCombo(keyCode, modifiers);

            if (entries.size() >= 2)
            {
                this.openWith(keyCode, entries);
                return true; // swallow to prevent original hotkey callbacks from firing
            }
            else if (keyCode == GLFW.GLFW_KEY_V)
            {
                // Temporary diagnostics for "V shows no wheel"
                StringBuilder sb = new StringBuilder(128);
                sb.append("Wheel candidates for V: ").append(entries.size()).append("  [");
                int max = Math.min(6, entries.size());
                for (int i = 0; i < max; i++)
                {
                    if (i > 0) sb.append(", ");
                    sb.append(entries.get(i).getConfigGuiDisplayName());
                }
                if (entries.size() > max) sb.append(", ...");
                sb.append("]");
                InfoUtils.showInGameMessage(Message.MessageType.INFO, sb.toString());
            }
        }

        return false;
    }

    private boolean isWheelBlockedByWhitelistForKeyPress(int keyCode, int modifiers)
    {
        List<String> whitelist = MaLiLibConfigs.Generic.HOTKEY_WHEEL_WHITELIST.getStrings();
        // Whitelist mode: empty whitelist => wheel disabled
        if (whitelist == null || whitelist.isEmpty())
        {
            return true;
        }

        String comboId = HotkeyWheelKeyComboUtil.buildComboIdFromEvent(keyCode, modifiers);
        if (comboId.isEmpty())
        {
            return true;
        }

        for (String raw : whitelist)
        {
            if (raw == null) continue;
            String s = raw.trim().toUpperCase(Locale.ROOT);
            if (s.isEmpty()) continue;
            if (s.equals(comboId))
            {
                return false;
            }
        }

        return true;
    }

    private List<IHotkey> collectHotkeysBoundToKeyCombo(int keyCode, int modifiers)
    {
        List<String> whitelist = MaLiLibConfigs.Generic.HOTKEY_WHEEL_WHITELIST.getStrings();
        if (whitelist == null || whitelist.isEmpty())
        {
            return new ArrayList<>();
        }

        String comboId = HotkeyWheelKeyComboUtil.buildComboIdFromEvent(keyCode, modifiers);
        if (comboId.isEmpty())
        {
            return new ArrayList<>();
        }

        Set<String> disabled = new LinkedHashSet<>();
        List<String> disabledRaw = MaLiLibConfigs.Generic.HOTKEY_WHEEL_DISABLED_PER_COMBO.getStrings();
        if (disabledRaw != null)
        {
            for (String s : disabledRaw)
            {
                if (s != null && s.trim().isEmpty() == false)
                {
                    disabled.add(s.trim());
                }
            }
        }

        // Whitelist blocks the wheel completely if the combo isn't allowed
        boolean allowed = false;
        for (String raw : whitelist)
        {
            if (raw == null) continue;
            String s = raw.trim().toUpperCase(Locale.ROOT);
            if (s.isEmpty()) continue;
            if (s.equals(comboId))
            {
                allowed = true;
                break;
            }
        }

        if (allowed == false)
        {
            return new ArrayList<>();
        }

        Set<IHotkey> out = new LinkedHashSet<>();
        for (KeybindCategory cat : InputEventHandler.getKeybindManager().getKeybindCategories())
        {
            if (cat == null) continue;
            for (IHotkey hk : cat.getHotkeys())
            {
                if (hk == null) continue;
                IKeybind kb = hk.getKeybind();
                if (kb == null) continue;

                String disabledId = comboId.toUpperCase(Locale.ROOT) + "|" + cat.getModName() + "|" + hk.getName();
                if (disabled.contains(disabledId))
                {
                    continue;
                }

                List<String> combos = HotkeyWheelKeyComboUtil.getComboIdsForKeybind(kb);
                for (String cid : combos)
                {
                    if (cid.equalsIgnoreCase(comboId))
                    {
                        out.add(hk);
                        break;
                    }
                }
            }
        }

        return new ArrayList<>(out);
    }

    @Override
    public boolean onMouseClick(int mouseX, int mouseY, int eventButton, boolean eventButtonState)
    {
        // When the wheel is open, consume mouse clicks too
        return this.open;
    }

    @Override
    public boolean onMouseScroll(int mouseX, int mouseY, double amount)
    {
        return this.open;
    }

    @Override
    public void onRenderGameOverlayPost(DrawContext drawContext)
    {
        if (this.open == false || this.mc.currentScreen != null)
        {
            return;
        }

        if (this.activeEntries.isEmpty())
        {
            return;
        }

        int cx = GuiUtils.getScaledWindowWidth() / 2;
        int cy = GuiUtils.getScaledWindowHeight() / 2;

        int radius = 55;
        int boxW = 90;
        int boxH = 14;

        // Background hint
        RenderUtils.drawRect(cx - 6, cy - 6, 12, 12, 0x60202020);

        for (int i = 0; i < this.activeEntries.size(); i++)
        {
            double ang = (-Math.PI / 2.0) + (2.0 * Math.PI) * ((double) i / (double) this.activeEntries.size());
            int tx = cx + (int) (Math.cos(ang) * radius);
            int ty = cy + (int) (Math.sin(ang) * radius);

            int bg = (i == this.selectedIndex) ? 0xB040A0FF : 0x90202020;
            RenderUtils.drawRect(tx - boxW / 2, ty - boxH / 2, boxW, boxH, bg);

            String label = this.activeEntries.get(i).getConfigGuiDisplayName();
            int textW = this.mc.textRenderer.getWidth(label);
            drawContext.drawTextWithShadow(this.mc.textRenderer, label, tx - textW / 2, ty - 4, 0xFFFFFF);
        }
    }

    private void updateSelectionFromMouse()
    {
        // Selection is handled by GuiHotkeyWheel while open.
    }

    private void triggerSelected()
    {
        if (this.selectedIndex < 0)
        {
            return;
        }

        if (this.selectedIndex >= this.activeEntries.size())
        {
            return;
        }

        IHotkey hotkey = this.activeEntries.get(this.selectedIndex);

        // If it's a togglable hotkey (boolean+hotkey), toggle the config value.
        if (hotkey instanceof IHotkeyTogglable togglable)
        {
            togglable.toggleBooleanValue();
            return;
        }

        // Otherwise, invoke the registered callback if available.
        IKeybind keybind = hotkey.getKeybind();
        if (keybind instanceof KeybindMulti multi)
        {
            IHotkeyCallback cb = multi.getCallback();
            if (cb != null)
            {
                cb.onKeyAction(KeyAction.PRESS, multi);
            }
        }
    }

    private void openWith(int keyCode, List<IHotkey> entries)
    {
        this.activeKeyCode = keyCode;
        this.activeEntries.clear();
        this.activeEntries.addAll(entries);
        this.open = true;
        this.selectedIndex = -1;

        this.parentScreen = this.mc.currentScreen;
        this.screen = new GuiHotkeyWheel(this.parentScreen, keyCode, this.activeEntries);
        this.mc.setScreen(this.screen);
    }

    private void close()
    {
        if (this.screen != null && this.mc.currentScreen == this.screen)
        {
            this.mc.setScreen(this.parentScreen);
            // Make sure camera control resumes immediately on release
            this.mc.mouse.lockCursor();
        }

        this.open = false;
        this.activeKeyCode = -1;
        this.activeEntries.clear();
        this.selectedIndex = -1;
        this.screen = null;
        this.parentScreen = null;
    }

    // (old ID-based whitelist collection removed; wheel now uses key-combo whitelist)
}

