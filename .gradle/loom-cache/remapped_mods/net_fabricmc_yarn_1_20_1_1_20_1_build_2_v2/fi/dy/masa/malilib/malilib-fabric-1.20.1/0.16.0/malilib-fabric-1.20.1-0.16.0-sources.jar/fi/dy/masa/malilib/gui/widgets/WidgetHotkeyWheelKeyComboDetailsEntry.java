package fi.dy.masa.malilib.gui.widgets;

import javax.annotation.Nullable;
import net.minecraft.client.gui.DrawContext;
import fi.dy.masa.malilib.gui.button.ButtonBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import fi.dy.masa.malilib.render.RenderUtils;

public class WidgetHotkeyWheelKeyComboDetailsEntry extends WidgetListEntryBase<WidgetListHotkeyWheelKeyComboDetails.HotkeyRef>
{
    private final boolean isOdd;
    private final WidgetListHotkeyWheelKeyComboDetails parent;
    private final ButtonGeneric toggleButton;
    private final int toggleButtonWidth;

    public WidgetHotkeyWheelKeyComboDetailsEntry(int x, int y, int width, int height,
            @Nullable WidgetListHotkeyWheelKeyComboDetails.HotkeyRef entry, int listIndex, boolean isOdd,
            WidgetListHotkeyWheelKeyComboDetails parent)
    {
        super(x, y, width, height, entry, listIndex);
        this.isOdd = isOdd;
        this.parent = parent;

        int bx = x + 2;
        int by = y + 2;
        int bw = 26;
        int bh = height - 4;
        this.toggleButtonWidth = bw;

        this.toggleButton = new ButtonGeneric(bx, by, bw, bh, this.getToggleLabel());
        this.addButton(this.toggleButton, new ListenerToggle(this));
    }

    private String getToggleLabel()
    {
        if (this.entry != null && this.parent.isDisabled(this.entry))
        {
            return "§c✖§r";
        }
        return "§a✔§r";
    }

    private void toggle()
    {
        if (this.entry == null) return;
        this.parent.toggle(this.entry);
        this.toggleButton.setDisplayString(this.getToggleLabel());
    }

    @Override
    public void render(int mouseX, int mouseY, boolean selected, DrawContext drawContext)
    {
        RenderUtils.color(1f, 1f, 1f, 1f);
        boolean disabled = this.entry != null && this.parent.isDisabled(this.entry);

        int bg = this.isOdd ? 0x20FFFFFF : 0x30FFFFFF;
        if (disabled)
        {
            bg = this.isOdd ? 0x30A02020 : 0x40A02020;
        }
        RenderUtils.drawRect(this.x, this.y, this.width, this.height, bg);

        if (this.entry != null)
        {
            int tx = this.x + 2 + this.toggleButtonWidth + 6;
            int ty = this.y + 5;
            String left = this.entry.modName + " | " + this.entry.displayName;
            this.drawStringWithShadow(tx, ty, 0xFFFFFFFF, left, drawContext);

            String right = this.entry.hotkeyName;
            int rw = this.getStringWidth(right);
            this.drawStringWithShadow(this.x + this.width - rw - 4, ty, 0xA0A0A0A0, right, drawContext);
        }

        this.drawSubWidgets(mouseX, mouseY, drawContext);
        super.render(mouseX, mouseY, selected, drawContext);
    }

    @Override
    protected boolean onMouseClickedImpl(int mouseX, int mouseY, int mouseButton)
    {
        if (mouseButton == 0 && this.entry != null)
        {
            this.toggle();
            return true;
        }
        return super.onMouseClickedImpl(mouseX, mouseY, mouseButton);
    }

    private static class ListenerToggle implements IButtonActionListener
    {
        private final WidgetHotkeyWheelKeyComboDetailsEntry parent;

        private ListenerToggle(WidgetHotkeyWheelKeyComboDetailsEntry parent)
        {
            this.parent = parent;
        }

        @Override
        public void actionPerformedWithButton(ButtonBase button, int mouseButton)
        {
            this.parent.toggle();
        }
    }
}

