package fi.dy.masa.malilib.gui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import fi.dy.masa.malilib.config.ConfigManager;
import fi.dy.masa.malilib.config.IConfigStringList;
import fi.dy.masa.malilib.event.InputEventHandler;
import fi.dy.masa.malilib.gui.interfaces.IConfigGui;
import fi.dy.masa.malilib.gui.interfaces.IDialogHandler;
import fi.dy.masa.malilib.gui.button.ButtonBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import fi.dy.masa.malilib.gui.widgets.WidgetListHotkeyWheelWhitelist;
import fi.dy.masa.malilib.render.RenderUtils;
import fi.dy.masa.malilib.util.GuiUtils;
import fi.dy.masa.malilib.util.StringUtils;

public class GuiHotkeyWheelWhitelistEdit extends GuiListBase<WidgetListHotkeyWheelWhitelist.KeyComboRef,
        fi.dy.masa.malilib.gui.widgets.WidgetHotkeyWheelWhitelistEntry,
        WidgetListHotkeyWheelWhitelist>
{
    protected final IConfigStringList config;
    protected final IConfigGui configGui;
    @Nullable protected final IDialogHandler dialogHandler;

    protected int dialogWidth;
    protected int dialogHeight;
    protected int dialogLeft;
    protected int dialogTop;

    public GuiHotkeyWheelWhitelistEdit(IConfigStringList config, IConfigGui configGui, @Nullable IDialogHandler dialogHandler, Screen parent)
    {
        super(0, 0);
        this.config = config;
        this.configGui = configGui;
        this.dialogHandler = dialogHandler;
        this.title = StringUtils.translate("malilib.gui.title.string_list_edit", config.getName());

        if (this.dialogHandler == null)
        {
            this.setParent(parent);
        }
    }

    @Override
    public void initGui()
    {
        // Ensure we see the latest keybind changes from all mods
        InputEventHandler.getKeybindManager().updateUsedKeys();

        // Responsive dialog size with side margins
        int sw = GuiUtils.getScaledWindowWidth();
        int sh = GuiUtils.getScaledWindowHeight();
        this.dialogWidth = Math.min(520, Math.max(360, sw - 80));
        this.dialogHeight = Math.min(320 + (sh * 2 / 3), Math.max(220, sh - 80));
        this.centerOnScreen();
        this.reCreateListWidget();
        super.initGui();

        int bx = this.dialogLeft + this.dialogWidth - 10;
        int by = this.dialogTop + 4;
        bx -= this.addTopButton(bx, by, "完成", TopAction.DONE) + 4;
        bx -= this.addTopButton(bx, by, "清空", TopAction.CLEAR) + 4;
    }

    private int addTopButton(int rightX, int y, String label, TopAction action)
    {
        ButtonGeneric btn = new ButtonGeneric(rightX, y, -1, true, label);
        this.addButton(btn, new ListenerTopButton(action, this));
        return btn.getWidth();
    }

    protected void centerOnScreen()
    {
        if (this.getParent() != null)
        {
            this.dialogLeft = this.getParent().width / 2 - this.dialogWidth / 2;
            this.dialogTop = this.getParent().height / 2 - this.dialogHeight / 2;
        }
        else
        {
            this.dialogLeft = 20;
            this.dialogTop = 20;
        }
        this.setListPosition(this.dialogLeft + 10, this.dialogTop + 20);
    }

    @Override
    protected int getBrowserWidth()
    {
        return this.dialogWidth - 14;
    }

    @Override
    protected int getBrowserHeight()
    {
        return this.dialogHeight - 30;
    }

    @Override
    protected WidgetListHotkeyWheelWhitelist createListWidget(int listX, int listY)
    {
        return new WidgetListHotkeyWheelWhitelist(listX, listY, this.getBrowserWidth(), this.getBrowserHeight(), this);
    }

    public IConfigStringList getConfig()
    {
        return this.config;
    }

    public Set<String> getSelectedIds()
    {
        return this.getListWidget().getSelectedIds();
    }

    @Override
    public void removed()
    {
        // Apply selection back to config
        List<String> out = new ArrayList<>(this.getSelectedIds());
        Collections.sort(out, String::compareToIgnoreCase);
        this.config.setStrings(out);
        ConfigManager.getInstance().onConfigsChanged(this.configGui.getModId());
        InputEventHandler.getKeybindManager().updateUsedKeys();
        super.removed();
    }

    @Override
    public void render(DrawContext drawContext, int mouseX, int mouseY, float partialTicks)
    {
        if (this.getParent() != null)
        {
            this.getParent().render(drawContext, mouseX, mouseY, partialTicks);
        }

        super.render(drawContext, mouseX, mouseY, partialTicks);
    }

    @Override
    protected void drawScreenBackground(int mouseX, int mouseY)
    {
        RenderUtils.drawOutlinedBox(this.dialogLeft, this.dialogTop, this.dialogWidth, this.dialogHeight, 0xFF000000, COLOR_HORIZONTAL_BAR);
    }

    @Override
    protected void drawTitle(DrawContext drawContext, int mouseX, int mouseY, float partialTicks)
    {
        this.drawStringWithShadow(drawContext, this.title, this.dialogLeft + 10, this.dialogTop + 6, COLOR_WHITE);
        int selected = this.getSelectedIds().size();
        String hint = "已选: " + selected + "  |  选择允许打开轮盘的按键组合  |  支持搜索";
        this.drawStringWithShadow(drawContext, hint, this.dialogLeft + 10, this.dialogTop + 6 + 12, 0xA0A0A0A0);
    }

    private enum TopAction
    {
        DONE,
        CLEAR
    }

    private static class ListenerTopButton implements IButtonActionListener
    {
        private final TopAction action;
        private final GuiHotkeyWheelWhitelistEdit parent;

        private ListenerTopButton(TopAction action, GuiHotkeyWheelWhitelistEdit parent)
        {
            this.action = action;
            this.parent = parent;
        }

        @Override
        public void actionPerformedWithButton(ButtonBase button, int mouseButton)
        {
            if (this.action == TopAction.DONE)
            {
                this.parent.closeGui(true);
            }
            else if (this.action == TopAction.CLEAR)
            {
                this.parent.getSelectedIds().clear();
                this.parent.getListWidget().getSelectedIds().clear();
                this.parent.initGui();
            }
        }
    }
}

