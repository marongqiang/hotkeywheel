package fi.dy.masa.malilib;

import java.io.File;
import com.google.common.collect.ImmutableList;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import fi.dy.masa.malilib.config.ConfigUtils;
import fi.dy.masa.malilib.config.IConfigBase;
import fi.dy.masa.malilib.config.IConfigHandler;
import fi.dy.masa.malilib.config.options.ConfigBoolean;
import fi.dy.masa.malilib.config.options.ConfigHotkey;
import fi.dy.masa.malilib.config.options.ConfigStringList;
import fi.dy.masa.malilib.util.FileUtils;
import fi.dy.masa.malilib.util.JsonUtils;

public class MaLiLibConfigs implements IConfigHandler
{
    private static final String CONFIG_FILE_NAME = MaLiLibReference.MOD_ID + ".json";

    public static class Generic
    {
        public static final ConfigHotkey    IGNORED_KEYS            = new ConfigHotkey("ignoredKeys", "", "Any keys set here will be completely ignored");
        public static final ConfigHotkey    OPEN_GUI_CONFIGS        = new ConfigHotkey("openGuiConfigs", "A,C", "Open the in-game malilib config GUI");
        public static final ConfigHotkey    HOTKEY_WHEEL            = new ConfigHotkey("hotkeyWheel", "H", "Hold to open the Hotkey Wheel.\nMove the mouse to select, release to trigger.");
        public static final ConfigStringList HOTKEY_WHEEL_WHITELIST = new ConfigStringList("hotkeyWheelWhitelist",
                ImmutableList.of(),
                "Hotkey Wheel key whitelist.\n" +
                "Only key combinations listed here are allowed to open the wheel.\n" +
                "If this list is empty, then the wheel is disabled (it will not open).\n" +
                "Each entry is in the storage format used by malilib keybinds.\n" +
                "Examples: V   /   LEFT_CONTROL,V   /   LEFT_SHIFT,V");
        // Internal storage (not exposed in the configs GUI): disabled hotkeys per key combo.
        // Each entry: "<comboId>|<modName>|<hotkeyName>"
        public static final ConfigStringList HOTKEY_WHEEL_DISABLED_PER_COMBO = new ConfigStringList("hotkeyWheelDisabledPerCombo",
                ImmutableList.of(),
                "INTERNAL - do not edit manually");
        public static final ConfigBoolean   REALMS_COMMON_CONFIG    = new ConfigBoolean("realmsCommonConfig", true, "Whether or not to use a common config file name for all realms servers.\nIf this is disabled, then the server IP and port are used in the generated config file names.\nHowever, apparently the Realms server addresses change regularly, so the config names would change\nall the time and thus the configs wouldn't save properly.\nSo basically leave this enabled if you only play on one Realms server.\nIf you play on multiple Realms... then the configs will get mixed up regardless.\nUnless you play on the different servers on different Minecraft instances\nto keep the configs separated by the Minecraft instance.");

        public static final ImmutableList<IConfigBase> OPTIONS = ImmutableList.of(
                IGNORED_KEYS,
                OPEN_GUI_CONFIGS,
                HOTKEY_WHEEL,
                HOTKEY_WHEEL_WHITELIST,
                REALMS_COMMON_CONFIG
        );
    }

    public static class Debug
    {
        public static final ConfigBoolean INPUT_CANCELLATION_DEBUG  = new ConfigBoolean("inputCancellationDebugging", false, "When enabled, then the cancellation reason/source\nfor inputs (keyboard and mouse) is printed out");
        public static final ConfigBoolean KEYBIND_DEBUG             = new ConfigBoolean("keybindDebugging", false, "When enabled, key presses and held keys are\nprinted to the game console (and the action bar, if enabled)");
        public static final ConfigBoolean KEYBIND_DEBUG_ACTIONBAR   = new ConfigBoolean("keybindDebuggingIngame", true, "If enabled, then the messages from 'keybindDebugging'\nare also printed to the in-game action bar");
        public static final ConfigBoolean MOUSE_SCROLL_DEBUG        = new ConfigBoolean("mouseScrollDebug", false, "If enabled, some debug values from mouse scrolling\nare printed to the game console/log");

        public static final ImmutableList<IConfigBase> OPTIONS = ImmutableList.of(
                INPUT_CANCELLATION_DEBUG,
                KEYBIND_DEBUG,
                KEYBIND_DEBUG_ACTIONBAR,
                MOUSE_SCROLL_DEBUG
        );
    }

    public static void loadFromFile()
    {
        File configFile = new File(FileUtils.getConfigDirectory(), CONFIG_FILE_NAME);

        if (configFile.exists() && configFile.isFile() && configFile.canRead())
        {
            JsonElement element = JsonUtils.parseJsonFile(configFile);

            if (element != null && element.isJsonObject())
            {
                JsonObject root = element.getAsJsonObject();

                ConfigUtils.readConfigBase(root, "Generic", Generic.OPTIONS);
                readInternalStringList(root, "Generic", "hotkeyWheelDisabledPerCombo", Generic.HOTKEY_WHEEL_DISABLED_PER_COMBO);
            }
        }
    }

    public static void saveToFile()
    {
        File dir = FileUtils.getConfigDirectory();

        if ((dir.exists() && dir.isDirectory()) || dir.mkdirs())
        {
            JsonObject root = new JsonObject();

            ConfigUtils.writeConfigBase(root, "Generic", Generic.OPTIONS);
            writeInternalStringList(root, "Generic", "hotkeyWheelDisabledPerCombo", Generic.HOTKEY_WHEEL_DISABLED_PER_COMBO);

            JsonUtils.writeJsonToFile(root, new File(dir, CONFIG_FILE_NAME));
        }
    }

    private static void readInternalStringList(JsonObject root, String categoryName, String key, ConfigStringList config)
    {
        if (root == null || config == null) return;
        if (root.has(categoryName) == false || root.get(categoryName).isJsonObject() == false) return;
        JsonObject cat = root.getAsJsonObject(categoryName);
        if (cat.has(key) == false || cat.get(key).isJsonArray() == false) return;

        JsonArray arr = cat.getAsJsonArray(key);
        ImmutableList.Builder<String> b = ImmutableList.builder();
        for (JsonElement e : arr)
        {
            if (e != null && e.isJsonPrimitive())
            {
                String s = e.getAsString();
                if (s != null && s.trim().isEmpty() == false)
                {
                    b.add(s.trim());
                }
            }
        }
        config.setStrings(b.build());
    }

    private static void writeInternalStringList(JsonObject root, String categoryName, String key, ConfigStringList config)
    {
        if (root == null || config == null) return;

        JsonObject cat = root.has(categoryName) && root.get(categoryName).isJsonObject()
                ? root.getAsJsonObject(categoryName)
                : new JsonObject();

        JsonArray arr = new JsonArray();
        for (String s : config.getStrings())
        {
            if (s != null && s.trim().isEmpty() == false)
            {
                arr.add(s.trim());
            }
        }

        cat.add(key, arr);
        root.add(categoryName, cat);
    }

    @Override
    public void onConfigsChanged()
    {
        saveToFile();
        loadFromFile();
    }

    @Override
    public void load()
    {
        loadFromFile();
    }

    @Override
    public void save()
    {
        saveToFile();
    }
}
