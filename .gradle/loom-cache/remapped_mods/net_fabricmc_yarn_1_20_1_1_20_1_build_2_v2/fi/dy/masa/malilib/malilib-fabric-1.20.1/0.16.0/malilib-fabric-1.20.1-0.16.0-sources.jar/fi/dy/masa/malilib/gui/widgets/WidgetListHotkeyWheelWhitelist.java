package fi.dy.masa.malilib.gui.widgets;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.Set;

import javax.annotation.Nullable;

import fi.dy.masa.malilib.MaLiLibReference;
import fi.dy.masa.malilib.event.InputEventHandler;
import fi.dy.masa.malilib.gui.GuiHotkeyWheelWhitelistEdit;
import fi.dy.masa.malilib.gui.LeftRight;
import fi.dy.masa.malilib.gui.MaLiLibIcons;
import fi.dy.masa.malilib.hotkeys.IHotkey;
import fi.dy.masa.malilib.hotkeys.IKeybind;
import fi.dy.masa.malilib.hotkeys.KeybindCategory;
import fi.dy.masa.malilib.hotkeys.wheel.HotkeyWheelKeyComboUtil;

public class WidgetListHotkeyWheelWhitelist extends WidgetListBase<WidgetListHotkeyWheelWhitelist.KeyComboRef, WidgetHotkeyWheelWhitelistEntry>
{
    public static class KeyComboRef
    {
        public final String comboId;
        public final String display;
        public final int boundCount;

        public KeyComboRef(String comboId, int boundCount)
        {
            this.comboId = comboId;
            this.display = HotkeyWheelKeyComboUtil.comboIdToDisplayString(comboId);
            this.boundCount = boundCount;
        }

        public String getId()
        {
            return this.comboId;
        }
    }

    private final GuiHotkeyWheelWhitelistEdit parent;
    private final Set<String> selectedIds = new HashSet<>();
    private boolean showOnlyBound = true;

    public WidgetListHotkeyWheelWhitelist(int x, int y, int width, int height, GuiHotkeyWheelWhitelistEdit parent)
    {
        super(x, y, width, height, null);
        this.parent = parent;
        this.widgetSearchBar = new WidgetSearchBar(x + 2, y + 4, width - 14, 14, 0, MaLiLibIcons.SEARCH, LeftRight.LEFT);
        this.browserEntriesOffsetY = 17;
        this.browserEntryHeight = 18;
        this.shouldSortList = false;

        // Load current selection from config
        for (String s : parent.getConfig().getStrings())
        {
            if (s != null && s.trim().isEmpty() == false)
            {
                this.selectedIds.add(s.trim());
            }
        }
    }

    public Set<String> getSelectedIds()
    {
        return this.selectedIds;
    }

    public boolean isShowOnlyBound()
    {
        return this.showOnlyBound;
    }

    public void setShowOnlyBound(boolean showOnlyBound)
    {
        if (this.showOnlyBound != showOnlyBound)
        {
            this.showOnlyBound = showOnlyBound;
            this.refreshEntries();
        }
    }

    public boolean isSelected(KeyComboRef ref)
    {
        return ref != null && this.selectedIds.contains(ref.getId());
    }

    public void toggle(KeyComboRef ref)
    {
        if (ref == null) return;
        String id = ref.getId();
        if (this.selectedIds.contains(id))
        {
            this.selectedIds.remove(id);
        }
        else
        {
            this.selectedIds.add(id);
        }
    }

    @Override
    protected java.util.Collection<KeyComboRef> getAllEntries()
    {
        // Make sure categories/used keys are up to date, otherwise newly bound combos
        // might not show up until the next full refresh.
        InputEventHandler.getKeybindManager().updateUsedKeys();

        List<KeybindCategory> categories = InputEventHandler.getKeybindManager().getKeybindCategories();
        Map<String, Integer> comboCounts = new LinkedHashMap<>();

        for (KeybindCategory category : categories)
        {
            if (category == null) continue;
            if (MaLiLibReference.MOD_NAME.equals(category.getModName()))
            {
                continue;
            }

            for (IHotkey hk : category.getHotkeys())
            {
                if (hk == null) continue;
                IKeybind kb = hk.getKeybind();
                if (kb == null || kb.getKeys().isEmpty())
                {
                    continue;
                }

                for (String comboId : HotkeyWheelKeyComboUtil.getComboIdsForKeybind(kb))
                {
                    if (comboId == null || comboId.isEmpty()) continue;
                    comboCounts.put(comboId, comboCounts.getOrDefault(comboId, 0) + 1);
                }
            }
        }

        List<KeyComboRef> out = new ArrayList<>(comboCounts.size());
        for (Map.Entry<String, Integer> e : comboCounts.entrySet())
        {
            out.add(new KeyComboRef(e.getKey(), e.getValue()));
        }

        out.sort((a, b) -> a.comboId.compareToIgnoreCase(b.comboId));

        return out;
    }

    @Override
    protected List<String> getEntryStringsForFilter(KeyComboRef entry)
    {
        if (entry == null)
        {
            return Collections.emptyList();
        }

        List<String> list = new ArrayList<>();
        list.add(entry.comboId.toLowerCase(Locale.ROOT));
        list.add(entry.display.toLowerCase(Locale.ROOT));
        return list;
    }

    @Override
    protected WidgetHotkeyWheelWhitelistEntry createListEntryWidget(int x, int y, int listIndex, boolean isOdd, @Nullable KeyComboRef entry)
    {
        return new WidgetHotkeyWheelWhitelistEntry(x, y, this.browserEntryWidth, this.browserEntryHeight, entry, listIndex, isOdd, this);
    }
}

